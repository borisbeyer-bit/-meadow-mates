MEADOW MATES v0.2

Prototype for iPhone/browser.
Controls:
- Left joystick: move
- SAMMELN: collect a nearby tree/rock
- PFLANZEN: plant a seed in front of you
- GIESSEN: water a nearby crop
- BAUEN: build a workbench for 5 wood + 3 stone
- SPEICHERN: save the persistent world locally

Next multiplayer milestone:
Room code + server-authoritative shared world + second live player.
